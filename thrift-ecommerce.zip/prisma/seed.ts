import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  const hashedPassword = await bcrypt.hash('admin123', 10)
  
  // Create admin user
  await prisma.user.upsert({
    where: { email: 'admin@thriftease.com' },
    update: {},
    create: {
      email: 'admin@thriftease.com',
      username: 'admin',
      password: hashedPassword,
      fullName: 'Admin ThriftEase',
      role: 'ADMIN',
    },
  })
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
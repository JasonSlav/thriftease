import transporter from './mailer';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
const JWT_SECRET_KEY = process.env.JWT_SECRET_KEY!;

const prisma = new PrismaClient();

// Helper: Generate random 4-digit OTP
const generateOTP = (): string => crypto.randomInt(1000, 9999).toString();

// Helper: Generate JWT with OTP and email
const generateJWT = (otp: string, email: string): string => {
  return jwt.sign({ otp, email }, JWT_SECRET_KEY, { expiresIn: '5m' }); // 5 minutes expiry
};

// Helper: Send email with the provided options
const sendEmail = async (to: string, subject: string, text: string): Promise<void> => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to,
    subject,
    text,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Email terkirim ke: ${to}`);
  } catch (error) {
    console.error(`Gagal mengirim email ke ${to}:`, error);
    throw new Error('Pengiriman email gagal, mohon coba lagi nanti.');
  }
};

// Function: Send OTP
const sendOTP = async (email: string): Promise<{ token: string; expiresIn: number }> => {
  const otp = generateOTP();
  const token = generateJWT(otp, email);
  const expiresIn = 300; // 5 minutes

  try {
    await sendEmail(email, 'Kode OTP ThriftEase', `Kode OTP Kamu adalah: ${otp}`);
  } catch (error) {
    throw new Error('Gagal mengirim OTP. Pastikan email valid dan coba lagi.');
  }

  return { token, expiresIn };
};

// Function: Resend OTP
const resendOTP = async (email: string): Promise<{ token: string; expiresIn: number }> => {
  return sendOTP(email); // Reuse sendOTP to avoid duplicating logic
};

// Function: Verify OTP
const attempts = new Map<string, number>(); // Map to track verification attempts

const verifyOTP = async (token: string, otpInput: string): Promise<boolean> => {
  try {
    const { otp, email } = jwt.verify(token, JWT_SECRET_KEY) as { otp: string; email: string };

    // Check if email has exceeded maximum attempts
    if (!attempts.has(email)) attempts.set(email, 0);

    if (attempts.get(email)! >= 3) {
      throw new Error('Terlalu banyak kesalahan, mohon coba lagi nanti.');
    }

    // Validate OTP
    if (otp === otpInput) {
      attempts.delete(email); // Reset attempts on success
      console.log('OTP Valid!');
      await prisma.user.update({
        where: {
          email: email,
        },
        data: {
          isVerified: true,
        },
      });
      return true;
    }

    // Increment attempts on failure
    attempts.set(email, attempts.get(email)! + 1);
    console.log('OTP Tidak Valid!');
    return false;
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      console.error('Token kedaluwarsa. Silakan minta OTP baru:', error);
      throw new Error('Token OTP telah kedaluwarsa.');
    } else {
      console.error('Token tidak valid:', error);
      throw new Error('Token atau kode OTP tidak valid.');
    }
  }
};

export async function sendResetEmail(email: string, token: string) {
  const resetUrl = `localhost:5173/reset-password?token=${token}`;
  const mailOptions = {
    from: 'Your App <your-zoho-email>',
    to: email,
    subject: 'Password Reset',
    text: `Click the link to reset your password: ${resetUrl}`,
  };

  await transporter.sendMail(mailOptions);
}

export { sendOTP, resendOTP, verifyOTP };
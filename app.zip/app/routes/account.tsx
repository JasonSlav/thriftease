import { useNavigate } from "@remix-run/react"; // Import useNavigate

const KelolaAkunPage = () => {
  const navigate = useNavigate(); // Initialize useNavigate

  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      <header className="relative flex items-center justify-between border-b pb-2 lg:pb-4 mb-4 lg:mb-6 w-full px-4 lg:px-8 bg-white pt-4">
        <button
          onClick={() => navigate(-1)} // Navigate ke halaman sebelumnya
          className="w-8 h-8 lg:w-10 lg:h-10 bg-yellow-300 rounded-full flex items-center justify-center"
        >
          <i className="fas fa-arrow-left"></i>
        </button>
        <h1 className="absolute left-1/2 transform -translate-x-1/2 text-xl lg:text-2xl font-bold">
          Kelola Akun
        </h1>
      </header>
      <main className="mr-4 ml-4">
        <div className="flex justify-center mb-4">
          <div className="bg-white w-14 h-14 rounded-full flex items-center justify-center">
            <i className="fas fa-user-circle text-7xl text-gray-300"></i>
          </div>
        </div>
        <div className="mb-4">
          <label className="block font-bold mb-1">Username</label>
          <div className="flex items-center bg-gray-200 p-2 rounded">
            <span>Joko_5892</span>
          </div>
        </div>
        <div className="mb-4">
          <label className="block font-bold mb-1">Email</label>
          <div className="flex items-center bg-gray-200 p-2 rounded">
            <span>jokoanwar@gmail.com</span>
            <button className="ml-auto text-gray-600">
              <i className="fas fa-pencil-alt"></i>
            </button>
          </div>
        </div>
        <div className="mb-4">
          <label className="block font-bold mb-1">No.Handphone</label>
          <div className="flex items-center bg-gray-200 p-2 rounded">
            <span>08213435667889</span>
            <button className="ml-auto text-gray-600">
              <i className="fas fa-pencil-alt"></i>
            </button>
          </div>
        </div>
        <div className="mb-4">
          <label className="block font-bold mb-1">Nama Lengkap</label>
          <div className="flex items-center bg-gray-200 p-2 rounded">
            <span>Joko Anwar</span>
            <button className="ml-auto text-gray-600">
              <i className="fas fa-pencil-alt"></i>
            </button>
          </div>
        </div>
        <div className="mb-4">
          <label className="block font-bold mb-1">Alamat</label>
          <div className="flex items-center bg-gray-200 p-2 rounded">
            <span>
              Jl. Pegangsaan Timur No.56 RT.1/RW.1, Pegangsaan, Kec. Menteng,
              Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10310
            </span>
            <button className="ml-auto text-gray-600">
              <i className="fas fa-pencil-alt"></i>
            </button>
          </div>
        </div>
        <div className="flex justify-center">
          <button className="w-full p-3 bg-yellow-300 text-black font-bold rounded shadow-md hover:bg-yellow-400">
            Simpan
          </button>
        </div>
      </main>
    </div>
  );
};

export default KelolaAkunPage;
import { useState } from "react";
import { useNavigate, useLoaderData } from "@remix-run/react";
import { json } from "@remix-run/node";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { getUser } from "~/utils/session.server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// Example in a Remix loader
export async function loader({ request }: LoaderFunctionArgs) {
    const user = await getUser(request); // Sesuaikan cara mendapatkan ID pengguna
    if (!user) {
      return json({ message: "User tidak ditemukan" }, { status: 401 });
    }
    const cartItems = await prisma.cart.findMany({
      where: { userId: user.id },
      include: { 
        items: {
          include: { product: true } // Ambil detail produk dari items
        }
      },
    });
    return json(cartItems);
  }

function KeranjangPage() {
  const navigate = useNavigate(); // Inisialisasi useNavigate
  const [selectedItems, setSelectedItems] = useState([false]); // Status checkbox item
  const [selectAll, setSelectAll] = useState(false); // Status checkbox "Pilih Semua"

  // Fungsi untuk menangani klik pada checkbox item
  const handleItemChange = (index) => {
    const updatedItems = [...selectedItems];
    updatedItems[index] = !updatedItems[index];
    setSelectedItems(updatedItems);

    // Update status "Pilih Semua"
    const allChecked = updatedItems.every((item) => item);
    setSelectAll(allChecked);
  };

  // Fungsi untuk menangani klik pada checkbox "Pilih Semua"
  const handleSelectAllChange = () => {
    const newState = !selectAll;
    setSelectAll(newState);
    setSelectedItems(selectedItems.map(() => newState));
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      {/* Header di luar max-width container untuk full lebar */}
      <header className="flex items-center justify-between border-b pb-2 lg:pb-4 mb-4 lg:mb-6 w-full px-4 lg:px-8 bg-white pt-4">
        <button
          onClick={() => navigate(-1)} // Navigate ke halaman sebelumnya
          className="w-8 h-8 lg:w-10 lg:h-10 bg-yellow-300 rounded-full flex items-center justify-center"
        >
          <i className="fas fa-arrow-left"></i>
        </button>
        <h1 className="text-xl lg:text-2xl font-bold">Keranjang</h1>
        <button className="text-yellow-300 text-2xl">
          <i className="fas fa-trash"></i>
        </button>
      </header>

      {/* Konten utama berada dalam max-width container */}
      <div className="w-full max-w-md lg:max-w-full mx-auto p-4 lg:p-8 flex-grow">
        <main className="p-4 flex-grow">
          <div className="bg-white rounded-lg shadow p-4 flex items-center mt-4">
            {/* Checkbox di sebelah kiri gambar */}
            <input
              type="checkbox"
              className="form-checkbox text-yellow-300 h-5 w-5 mr-4"
              checked={selectedItems[0]}
              onChange={() => handleItemChange(0)}
            />

            {/* Gambar produk */}
            <img
              src="https://placehold.co/100x100"
              alt="Ra Cloth Jaket Tracktop Vintage Putih Petrol Salvia Hexis Jaket Parasut Sport"
              className="w-20 h-20 object-cover rounded-md"
            />

            {/* Konten Utama */}
            <div className="ml-4 flex-grow">
              <p className="font-semibold line-clamp-2 overflow-hidden text-ellipsis">
                Ra Cloth Jaket Tracktop Vintage Putih Petrol Salvia Hexis Jaket
                Parasut Sport
              </p>
              <p className="text-gray-600">Size: XL</p>

              {/* Harga dan kontrol jumlah dengan space-between */}
              <div className="flex justify-between items-center mt-2">
                <p className="font-semibold text-yellow-300">Rp 100.000</p>

                <div className="flex items-center space-x-1">
                  <button className="w-6 h-6 bg-yellow-300 text-white rounded-full flex items-center justify-center">
                    <i className="fas fa-minus text-xs"></i>
                  </button>
                  <span className="px-2 border border-gray-300 rounded-md text-sm">
                    1
                  </span>
                  <button className="w-6 h-6 bg-yellow-300 text-white rounded-full flex items-center justify-center">
                    <i className="fas fa-plus text-xs"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Footer tetap pada max-width container */}
      <footer className="w-full max-w-md lg:max-w-full mx-auto bg-white shadow p-4 flex items-center justify-between sticky bottom-0 px-4 lg:px-8">
        <div className="flex items-center">
          <input
            type="checkbox"
            className="form-checkbox text-yellow-300 h-5 w-5"
            checked={selectAll}
            onChange={handleSelectAllChange}
          />
          <span className="ml-2">Pilih Semua</span>
        </div>
        <div className="flex">
          <div className="text-right mr-4">
            <p className="text-sm">Total</p>
            <p className="text-yellow-300 font-bold text-lg">Rp 100.000</p>
          </div>
          <button
            className="bg-yellow-300 text-black font-semibold py-2 px-4 rounded-lg"
            onClick={() => navigate("/pesanan")} 
          >
            Pesan (1)
          </button>
        </div>
      </footer>
    </div>
  );
}

export default KeranjangPage;

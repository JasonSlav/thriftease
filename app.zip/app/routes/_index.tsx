import { MetaFunction, ActionFunction, LoaderFunctionArgs, json, redirect } from "@remix-run/node";
import { useNavigate } from "@remix-run/react";
import { getSession } from "~/utils/session.server";
import { authenticator } from "~/utils/auth.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const user = await authenticator.isAuthenticated(request);
  if (!user) {
    return redirect("/login");
  }
  return 0;
};

export const action: ActionFunction = async ({ request }) => {
  await getSession(request);
  return null;
};

export const meta: MetaFunction = () => {
  return [
    { title: "Thrift Ease" },
    { name: "description", content: "Welcome to Remix!" },
  ];
};

export default function Index() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-yellow-300 p-4 sticky top-0 w-full z-10">
        <div className="flex items-center justify-center relative">
          <div className="relative w-3/4">
            <i className="fas fa-search absolute top-1/2 left-4 transform -translate-y-1/2 text-gray-300"></i>
            <input
              type="text"
              placeholder="Jaket"
              className="w-full p-2 pl-10 rounded-full border border-gray-300"
            />
          </div>
        </div>
      </header>

      <div className="pt-20 bg-gray-100 p-4 flex justify-center">
        <div className="bg-white p-4 rounded-lg shadow-md flex items-center justify-between w-full md:w-1/2">
          <img
            src="https://placehold.co/100x100"
            alt="Man in checkered shirt"
            className="rounded-full w-16 h-16"
          />
          <h1 className="text-xl font-bold text-center">
            Jelajahi Gaya Thrift Terbaik
          </h1>
          <img
            src="https://placehold.co/100x100"
            alt="Woman in denim jacket"
            className="rounded-full w-16 h-16"
          />
        </div>
      </div>

      {/* Category Section */}
      <div className="bg-gray-100 p-4 flex justify-center">
        <div className="w-full md:w-1/2">
          <h2 className="text-xl font-bold mb-4 text-center">KATEGORI</h2>
          <div className="grid grid-cols-4 gap-4">
            {[
              "Jaket",
              "Kemeja",
              "Kaos",
              "Celana",
              "Topi",
              "Sepatu",
              "Dress",
              "Tas",
            ].map((category, index) => (
              <div
                key={index}
                className="bg-white p-4 rounded-lg shadow-md flex flex-col items-center"
              >
                <img
                  src={`https://placehold.co/100x100`}
                  alt={category}
                  className="w-16 h-16 mb-2"
                />
                <span>{category}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recommendations Section */}
      <div className="bg-gray-100 p-4">
        <h2 className="text-xl font-bold mb-4 text-center">REKOMENDASI</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2 sm:gap-4">
          {[
            {
              title:
                "Ra Cloth Jaket Tracktop Vintage Putih Patrol Salvia Havia Jaket Parasut Sport",
              price: "Rp 100.000",
              size: "XL",
              img: "https://placehold.co/300x300?text=Jacket+1",
            },
            {
              title:
                "Varsity Jacket Vintage Soft Parasut Waterproof Pria Estima",
              price: "Rp 70.000",
              size: "S",
              img: "https://placehold.co/300x300?text=Jacket+2",
            },
            {
              title: "Russ Sweater Hoodie Pria Oldskull Misty",
              price: "Rp 120.000",
              size: "L",
              img: "https://placehold.co/300x300?text=Jacket+3",
            },
            {
              title: "Kemeja Slim Fit Easy-Iron H&M",
              price: "Rp 80.000",
              size: "M",
              img: "https://placehold.co/300x300?text=Jacket+4",
            },
            {
              title:
                "OVRDZ - Sweater Crewneck Rugby Sweatshirt Bordir Pria Wanita Switer Cowok",
              price: "Rp 150.000",
              size: "XL",
              img: "https://placehold.co/300x300?text=Jacket+5",
            },
            {
              title: "Adidas Samba OG Black White Gum",
              price: "Rp 80.000",
              size: "42",
              img: "https://placehold.co/300x300?text=Jacket+6",
            },
            {
              title: "Kremlin Tracktop Suit Jacket - Autodrive",
              price: "Rp 120.000",
              size: "L",
              img: "https://placehold.co/300x300?text=Jacket+7",
            },
            {
              title: "DRITTONZIO Work Jaket Bay 'Duck' unisex - Coklat",
              price: "Rp 80.000",
              size: "L",
              img: "https://placehold.co/300x300?text=Jacket+8",
            },
          ].map((product, index) => (
            <div
              key={index}
              className="bg-white p-2 sm:p-4 rounded-lg shadow-md text-xs sm:text-base"
            >
              <img
                src={product.img}
                alt={`Product ${index + 1}`}
                className="w-full h-32 sm:h-48 object-cover mb-2 sm:mb-4 rounded-lg"
              />
              <h2 className="text-gray-800 font-semibold mb-1 sm:mb-2">
                {product.title}
              </h2>
              <p className="text-gray-600 mb-1 sm:mb-2">Size: {product.size}</p>
              <p className="text-yellow-300 font-bold">{product.price}</p>
            </div>
          ))}
        </div>
        <div className="flex justify-center mt-4 mb-4">
          <button className="bg-yellow-300 text-white px-4 sm:px-6 py-2 rounded-full text-xs sm:text-base">
            Produk Lainnya
          </button>
        </div>
      </div>

      <footer className="bottom-0 w-full bg-yellow-300 p-4 flex justify-around items-center z-10 sticky">
        <div
          className="flex flex-col items-center cursor-pointer"
          onClick={() => navigate("/")} // Navigate to /home
        >
          <i className="fas fa-home text-2xl text-white"></i>
          <span className="text-white text-sm font-bold">Beranda</span>
        </div>
        <div
          className="flex flex-col items-center cursor-pointer"
          onClick={() => navigate("/cart")} // Navigate to /keranjang
        >
          <i className="fas fa-shopping-cart text-2xl text-white"></i>
          <span className="text-white text-sm font-bold">Keranjang</span>
        </div>
        <div
          className="flex flex-col items-center cursor-pointer"
          onClick={() => navigate("/profile")} // Navigate to /profile
        >
          <i className="fas fa-user text-2xl text-white"></i>
          <span className="text-white text-sm font-bold">Saya</span>
        </div>
      </footer>
    </div>
  );
}
import { useLoaderData } from "@remix-run/react";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const loader = async () => {
  const products = await prisma.product.findMany({
    include: {
      images: true,
    },
  });
  return { products };
};

export default function ProdukListPage() {
  const { products } = useLoaderData();

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-md p-4 relative flex justify-center items-center">
        <h1 className="text-xl font-bold text-center">Daftar Produk</h1>
      </header>
      <main className="m-4">
        <table className="w-full table-auto border-collapse">
          <thead>
            <tr>
              <th className="border p-2">Nama Produk</th>
              <th className="border p-2">Harga</th>
              <th className="border p-2">Stok</th>
              <th className="border p-2">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id}>
                <td className="border p-2">{product.name}</td>
                <td className="border p-2">{product.price}</td>
                <td className="border p-2">{product.stock}</td>
                <td className="border p-2">
                  <button className="bg-yellow-300 p-1 rounded-md">
                    Edit
                  </button>
                  <button className="bg-red-300 p-1 rounded-md ml-2">
                    Hapus
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </main>
    </div>
  );
}
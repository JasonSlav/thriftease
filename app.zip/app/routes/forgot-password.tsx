// routes/api/forgot-password.ts
import { json, type LoaderFunctionArgs } from '@remix-run/node';
import { redirect } from '@remix-run/node';
import { sendResetEmail } from '~/utils/jwt.server';
import { prisma } from '~/utils/prisma.server';
import crypto from 'crypto';

export async function POST({ request }: LoaderFunctionArgs) {
  const { email } = await request.json();
  const user = await prisma.user.findUnique({ where: { email } });

  if (!user) {
    // Redirect to a page indicating that the email was not found
    return redirect('/forgot-password?error=not-found');
  }

  const resetToken = crypto.randomBytes(20).toString('hex');
  const resetTokenExpiresAt = new Date(Date.now() + 3600000); // 1 hour

  await prisma.user.update({
    where: { id: user.id },
    data: { resetToken, resetTokenExpiresAt },
  });

  await sendResetEmail(email, resetToken);

  // Redirect to a page indicating that the email was sent
  return redirect('/forgot-password?message=check-email');
}
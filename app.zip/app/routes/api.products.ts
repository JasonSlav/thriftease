import { json, ActionFunction } from "@remix-run/node";
import { PrismaClient } from "@prisma/client";
import * as fs from "fs";
import * as path from "path";

const prisma = new PrismaClient();

export const action: ActionFunction = async ({ request }) => {
  const formData = await request.formData();
  const name = formData.get("name") as string;
  const description = formData.get("description") as string;
  const price = parseFloat(formData.get("price") as string);
  const stock = parseInt(formData.get("stock") as string);
  const category = formData.get("category") as string;

  // Mendapatkan gambar dari form data
  const image = formData.get("image") as File | null;
  let imageUrl = null;

  if (image) {
    const fileName = `${Date.now()}-${image.name}`;
    const filePath = path.join(process.cwd(), "public", "uploads", fileName);

    // Membaca file gambar sebagai Buffer
    const buffer = Buffer.from(await image.arrayBuffer()); // Mengonversi file ke buffer

    // Menyimpan gambar sebagai file
    await fs.promises.writeFile(filePath, buffer);
    imageUrl = `/uploads/${fileName}`;
  }

  // Menyimpan produk ke database
  const product = await prisma.product.create({
    data: {
      name,
      description,
      price,
      stock,
      category,
      images: imageUrl ? [{ url: imageUrl }] : [], // Menambahkan gambar jika ada
    },
  });

  return json({ product });
};
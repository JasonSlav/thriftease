import { useState, useEffect } from "react";
import { useNavigate } from "@remix-run/react";

const TambahProdukPage = () => {
  const navigate = useNavigate();
  const [isDescriptionPopupOpen, setDescriptionPopupOpen] = useState(false);
  const [description, setDescription] = useState("");
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");
  const [category, setCategory] = useState("");
  const [images, setImages] = useState<File[]>([]); // State untuk gambar yang dipilih
  const [previewImages, setPreviewImages] = useState<string[]>([]); // State untuk preview gambar

  const toggleDescriptionPopup = () => {
    setDescriptionPopupOpen(!isDescriptionPopupOpen);
  };

  const handleDescriptionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const formattedText = e.target.value
      .replace(/^- /gm, "• ")
      .replace(/\n/g, "<br/>");
    setDescription(formattedText);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const fileArray = Array.from(files);
      setImages(fileArray); // Menyimpan array file yang dipilih

      // Membuat preview untuk setiap gambar yang dipilih
      const previews: string[] = fileArray.map((file) =>
        URL.createObjectURL(file)
      );
      setPreviewImages(previews); // Menyimpan URL objek untuk preview gambar
    }
  };

  // Perbarui pengiriman FormData di frontend
const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();

  const formData = new FormData();
  formData.append("name", name);
  formData.append("description", description);
  formData.append("price", price);
  formData.append("stock", stock);
  formData.append("category", category);

  // Menambahkan gambar jika ada gambar yang dipilih
  if (images.length > 0) {
    images.forEach((image) => formData.append("images[]", image)); // Mengirim gambar sebagai array
  }

  const response = await fetch("/api/products", {
    method: "POST",
    body: formData,
  });

  if (response.ok) {
    navigate("/admin/products");
  } else {
    alert("Failed to add product");
  }
};

  // Pembersihan URL object saat komponen di-unmount atau gambar diganti
  useEffect(() => {
    // Bersihkan preview ketika komponen dilepas atau gambar berubah
    return () => {
      previewImages.forEach((preview) => URL.revokeObjectURL(preview));
    };
  }, [previewImages]);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-md p-4 relative flex justify-center items-center">
        <button
          className="absolute left-4 text-2xl text-black bg-yellow-300 w-10 h-10 rounded-full"
          onClick={() => navigate(-1)}
        >
          <i className="fas fa-arrow-left"></i>
        </button>
        <h1 className="text-xl font-bold text-center">Tambah Produk</h1>
      </header>
      <main className="m-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex flex-col items-center mb-4 mt-4">
            <div className="w-24 h-24 border-2 border-dashed border-gray-400 flex items-center justify-center">
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleImageChange}
                className="hidden"
                id="product-images"
              />
              <label htmlFor="product-images" className="cursor-pointer">
                {previewImages.length > 0 ? (
                  <div className="flex space-x-2">
                    {previewImages.map((src, index) => (
                      <img
                        key={index}
                        src={src}
                        alt={`Preview ${index}`}
                        className="w-16 h-16 object-cover"
                      />
                    ))}
                  </div>
                ) : (
                  <i className="fas fa-plus text-gray-400 text-2xl"></i>
                )}
              </label>
            </div>
          </div>
          <input
            type="text"
            placeholder="Nama Produk"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-2 border rounded-md"
          />
          <div className="flex items-center relative">
            <div
              className="w-full p-2 border rounded-md bg-white cursor-pointer text-gray-500"
              onClick={toggleDescriptionPopup}
              dangerouslySetInnerHTML={{ __html: description || "Deskripsi Produk" }}
            ></div>
            <button
              onClick={toggleDescriptionPopup}
              className="absolute right-2 text-gray-500"
            >
              <i className="fas fa-chevron-right"></i>
            </button>
          </div>
          <div className="flex space-x-2">
            <input
              type="text"
              placeholder="Harga"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="w-full p-2 border rounded-md"
            />
            <input
              type="text"
              placeholder="Ukuran"
              className="w-full p-2 border rounded-md"
            />
            <input
              type="text"
              placeholder="Stok"
              value={stock}
              onChange={(e) => setStock(e.target.value)}
              className="w-full p-2 border rounded-md"
            />
          </div>
          <input
            type="text"
            placeholder="Kategori"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full p-2 border rounded-md"
          />
          <button className="w-full p-2 bg-yellow-300 text-white rounded-md" type="submit">
            Tambah Produk
          </button>
        </form>
      </main>

      {/* Description Popup */}
      {isDescriptionPopupOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-4 rounded-lg w-80 relative">
            <button
              onClick={toggleDescriptionPopup}
              className="absolute top-2 right-2 text-gray-600 text-xl"
            >
              &times;
            </button>
            <h2 className="text-center text-lg font-semibold mb-4">Masukkan Deskripsi Produk:</h2>
            <textarea
              rows="4"
              placeholder="Deskripsi Produk"
              value={description.replace(/<br\/>/g, "\n")} // Show line breaks in textarea
              onChange={handleDescriptionChange}
              className="w-full p-2 border rounded-md text-gray-500"
            />
            <button
              onClick={toggleDescriptionPopup}
              className="w-full p-2 mt-4 bg-yellow-300 text-white rounded-md"
            >
              Simpan
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TambahProdukPage;